<?php
if(isset($_POST['submit'])){
  $url="https://www.google.com/recaptcha/api/siteverify";
    $data =[
      'secret' => "6LddpwAVAAAAAFhqWP4QcZUwWSlQRX8s4lbhkoc8",
      'response' => $_POST['g-recaptcha-response'],
       'remoteip' => $_SERVER['REMOTE_ADDR']
    ];
    $option = array(
      'http' => array(
        'header' => "Content-type: application/
        x-www-form-urlencoded\r\n",
        'method' => 'POST',
        'content' => http_build_query($data)
       )
    );
    $context = stream_context_create($option);
    $response = file_get_contents($url, false, $context);
echo "<pre>";
    print_r(json_decode($response, true));
echo "</pre>";
$result = json_decode($response, true);

if($result['success'] == true){
  echo "success";
}
else {
  echo "failed";
}



$name=$_POST['name'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$skype=$_POST['skype'];
$message=$_POST['help'];
$selbs=$_POST['buysale'];
$selct=$_POST['calltype'];
$to="kushwahad00@gmail.com";
$to1="sharadmcp2003@gmail.com";
$to2="tech@buythecalls.com";
$subject="New Inquiry From buythecalls.com";

$body="Message Body :\n\nName: ".$name."\n\nEmail: ".$email."\n\nPhone no.: ".$phone.
"\n\nSkype ID: ".$skype."\n\nSelected buy/sale: ".$selbs."\n\nSelected Call type: ".$selct."\n\nMessage: ".$message."\n\n\n\n\n------\nThis e-mail was sent from a inquiry form on Buy The Calls.
(https://buythecalls.com)";

$headers="From:buythecalls.com <tech@buythecalls.com>";

$user_body="Dear ".$name."\n Thanks we have received your email,\n
We sell calls and data in almost all verticals.\n
Please share your Contact Number and name so that we can call you.
Or Just add us on Skype - https://join.skype.com/invite/VGuNAudeaeA2 or call us back on +91-8377-825-955 to discuss further.
\n\n\n\n------\nThis is system generated e-mail please do not reply to this mail, we'll contact you shortly.";
if(mail($to1,$subject,$body,$headers) && mail($to,$subject,$body,$headers) && mail($to2,$subject,$body,$headers)){
  mail($email,"Thank  you for contacting us.",$user_body,$headers);?>
<script>
alert("Message Sent!\n thank you for contacting us, we'll contact you soon.");
  location.replace("/");

</script><?php
exit();
}
else {?>
  <script>
alert("Message did not Send!\n Try again.");
    location.replace("/");
  </script><?php
  exit();
}

}
 ?>
